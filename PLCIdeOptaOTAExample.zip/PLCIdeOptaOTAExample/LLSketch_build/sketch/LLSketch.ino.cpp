#line 1 "C:\\Users\\fabri\\Documents\\OptaOta\\LLSketch\\LLSketch.ino"
#include <AlPlc_Opta.h>

/* opta_1.1.0
      - Ethernet (1.0.0)
      - Arduino_Portenta_OTA (1.2.1)
*/

struct PLCSharedVarsInput_t
{
	bool in_d1;
	bool in_d2;
	bool in_d3;
	bool in_d4;
};
PLCSharedVarsInput_t& PLCIn = (PLCSharedVarsInput_t&)m_PLCSharedVarsInputBuf;

struct PLCSharedVarsOutput_t
{
};
PLCSharedVarsOutput_t& PLCOut = (PLCSharedVarsOutput_t&)m_PLCSharedVarsOutputBuf;


AlPlc AxelPLC(2009179522);

#include <Arduino.h>
#include <Portenta_Ethernet.h>
#include <Arduino_Portenta_OTA.h>

const char *filename = "http://192.168.10.2:8000/OPTABLINK.OTA";

#line 31 "C:\\Users\\fabri\\Documents\\OptaOta\\LLSketch\\LLSketch.ino"
void setup();
#line 38 "C:\\Users\\fabri\\Documents\\OptaOta\\LLSketch\\LLSketch.ino"
void loop();
#line 51 "C:\\Users\\fabri\\Documents\\OptaOta\\LLSketch\\LLSketch.ino"
void doOTAUpdate(const char *url);
#line 31 "C:\\Users\\fabri\\Documents\\OptaOta\\LLSketch\\LLSketch.ino"
void setup() {
  IPAddress ip(192, 168, 10, 15);
  Ethernet.begin(ip);

	AxelPLC.Run();
}

void loop() {
  PLCIn.in_d1 = true;
  PLCIn.in_d2 = true;
  PLCIn.in_d3 = true;
  PLCIn.in_d4 = true;
  
  delay(2000);

  doOTAUpdate(filename);
  
  delay(2000);
}

void doOTAUpdate(const char *url) {
  Arduino_Portenta_OTA_QSPI ota(QSPI_FLASH_FATFS_MBR, 2);
  Arduino_Portenta_OTA::Error ota_err = Arduino_Portenta_OTA::Error::None;

  if ((ota_err = ota.begin()) != Arduino_Portenta_OTA::Error::None) {
    PLCIn.in_d1 = false;
    return;
  }

  int const ota_download_res = ota.downloadAndDecompress(url, false, static_cast<MbedSocketClass *>(&Ethernet));
  if (ota_download_res <= 0) {
    PLCIn.in_d2 = false;
    return;
  }

  if ((ota_err = ota.update()) != Arduino_Portenta_OTA::Error::None) {
    PLCIn.in_d3 = false;
    return;
  }

  unsigned long start = millis();
  int waitSec = 5;
  while (millis() < (start + waitSec * 1000)) {
    PLCIn.in_d4 = false;
    delay(200);
    PLCIn.in_d4 = true;
    delay(200);
  }

  ota.reset();
}

